<!-- Jquery JS-->
<script src="<?php echo base_url('assets/vendor/jquery/jquery.min.js'); ?>"></script>

<!-- Vendor JS-->
<script src="<?php echo base_url('assets/vendor/select2/select2.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/vendor/datepicker/moment.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/vendor/datepicker/daterangepicker.js'); ?>"></script>

<!-- Main JS-->
<script src="<?php echo base_url('assets/js/global.js'); ?>"></script>