<!-- <script src="<?php //echo base_url('/assets/js/jquery-1.12.4.js'); ?>"></script>
<script src="<?php //echo base_url('/assets/js/jquery.dataTables.min.js'); ?>"></script>
<script src="<?php //echo base_url('/assets/js/dataTables.bootstrap.min.js'); ?>"></script>
 -->
 <script 
 	src="https://code.jquery.com/jquery-3.4.0.min.js" 
 	integrity="sha256-BJeo0qm959uMBGb65z40ejJYGSgR7REI4+CW1fNKwOg=" crossorigin="anonymous"></script>
 <!-- Latest compiled and minified JavaScript -->
<script 
	src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" 
	integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" 
	crossorigin="anonymous"></script>

<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap.min.js"></script>