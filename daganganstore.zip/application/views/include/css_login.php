<!-- Icons font CSS-->
<link href="<?php echo base_url('/assets/vendor/mdi-font/css/material-design-iconic-font.min.css'); ?>" rel="stylesheet" media="all">
<link href="<?php echo base_url('/assets/vendor/font-awesome-4.7/css/font-awesome.min.css'); ?>" rel="stylesheet" media="all">

<!-- Font special for pages-->
<link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet">

<!-- Vendor CSS-->
<link href="<?php echo base_url('/assets/vendor/select2/select2.min.css'); ?>" rel="stylesheet" media="all">
<link href="<?php echo base_url('/assets/vendor/datepicker/daterangepicker.css'); ?>" rel="stylesheet" media="all">

<!-- Main CSS-->
<link href="<?php echo base_url('/assets/css/loginregister.css'); ?>" rel="stylesheet" media="all">


<!--  -->
<link rel="shortcut icon" type="image/png" href='<?php echo base_url("assets/images/logo/asset_tokokita_pemweb_logo-0.png"); ?>'>