<br><br><br>

<div class="text-center footer">
	<p>&copy; 2019 tokokita Indonesia</p>
</div>

<style>
	.footer{
		position: fixed;
		left: 0;
		bottom: 0;
		width: 100%;
		background-color: #333333;
		color: #EEEEEE;
		text-align: center;
		padding-top: 8px;
	}
</style>
