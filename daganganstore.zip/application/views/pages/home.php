<!DOCTYPE html>
<html>
<head>

	<?php 
		echo $js;
		echo $css;
	?>
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<title>tokokita</title>
</head>
<body>
	<?php echo $header; ?>
	
	<?php echo $content; ?>
	
	<?php echo $footer; ?>
</body>
</html>